-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 08-05-2014 a las 13:29:24
-- Versión del servidor: 6.0.4
-- Versión de PHP: 6.0.0-dev

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `controlfei`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alumno`
-- 

CREATE TABLE `alumno` (
  `nombre` varchar(40) NOT NULL,
  `apepat` varchar(40) NOT NULL,
  `apemat` varchar(40) NOT NULL,
  `correo_electronico` varchar(40) NOT NULL,
  `estado` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `alumno`
-- 

INSERT INTO `alumno` VALUES ('nico', '', '', 'nico_como@gmail.com', '');
INSERT INTO `alumno` VALUES ('veronico', '', '', 'veronico_aries@hotmail.com', '');
INSERT INTO `alumno` VALUES ('veronico', 'Cordoba', 'Rivera', 'veronico_aries@hotmail.com', '');
INSERT INTO `alumno` VALUES ('Juan', 'CordobaPerez', 'RiveraCastillo', 'Castillo@hotmail.com', '');
INSERT INTO `alumno` VALUES ('sirio', 'torres', 'cruz', 'tuti2012@hotmail.com', '');
INSERT INTO `alumno` VALUES ('nico', 'Cordoba', 'Rivera', 'nico_como@gmail.com', '');
INSERT INTO `alumno` VALUES ('ncio', 'Cordoba', 'Cordoba', 'nico_23@hotmail.com', '');
INSERT INTO `alumno` VALUES ('nico', '', '', '', '');
INSERT INTO `alumno` VALUES ('', '', '', '', '');
INSERT INTO `alumno` VALUES ('nico', '', '', '', '');
INSERT INTO `alumno` VALUES ('nico', '', '', '', '');
INSERT INTO `alumno` VALUES ('nico', '', '', '', '');
INSERT INTO `alumno` VALUES ('nico', '', '', '', '');
INSERT INTO `alumno` VALUES ('', '', '', '', '');
INSERT INTO `alumno` VALUES ('', '', '', '', '');
INSERT INTO `alumno` VALUES ('', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cursos`
-- 

CREATE TABLE `cursos` (
  `idcurso` int(20) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `tipo` varchar(40) NOT NULL,
  `estado` varchar(40) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_conclusion` date NOT NULL,
  PRIMARY KEY (`idcurso`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `cursos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuario`
-- 

CREATE TABLE `usuario` (
  `idusuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) CHARACTER SET utf8 NOT NULL,
  `apepat` varchar(40) CHARACTER SET utf8 NOT NULL,
  `apemat` varchar(40) CHARACTER SET utf8 NOT NULL,
  `usuario` varchar(40) CHARACTER SET utf8 NOT NULL,
  `Email` varchar(40) CHARACTER SET utf8 NOT NULL,
  `password` varchar(40) CHARACTER SET utf8 NOT NULL,
  `confirmacion` varchar(40) CHARACTER SET utf8 NOT NULL,
  `rol` varchar(40) CHARACTER SET utf8 NOT NULL,
  `estado` varchar(45) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin AUTO_INCREMENT=37 ;

-- 
-- Volcar la base de datos para la tabla `usuario`
-- 

INSERT INTO `usuario` VALUES (36, 'Antonio', 'Cerdan', 'Yerena', 'Cerdan', 'Cerdan@hotmail.com', '123456', '123456', 'Academico', 'Activo');
INSERT INTO `usuario` VALUES (35, 'Anel', 'Martinez', 'Palestina', 'Anel', 'Anel-2345@hotmail.com', '098T', '098T', 'Administrador', 'Activo');
INSERT INTO `usuario` VALUES (29, 'veronico', 'Cordoba', 'Rivera', 'root', 'veronico_aries@hotmail.com', '123', '123', 'Administrador', 'Activo');
INSERT INTO `usuario` VALUES (30, 'nico', 'Hernandez', 'Fernandez', 'root2', 'nico_12@hotmail.com', '345', '345', 'Academico', 'Inactivo');
INSERT INTO `usuario` VALUES (31, 'Raul', 'Carmona', 'Contreras', 'Vega', 'Vega_aries@hotmail.com', '567', '567', 'Academico', 'Activo');
