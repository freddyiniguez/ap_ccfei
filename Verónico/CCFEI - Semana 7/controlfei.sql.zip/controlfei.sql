-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 27-05-2014 a las 14:26:00
-- Versión del servidor: 6.0.4
-- Versión de PHP: 6.0.0-dev

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `controlfei`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alumno`
-- 

CREATE TABLE `alumno` (
  `nombre` varchar(40) NOT NULL,
  `apepat` varchar(40) NOT NULL,
  `apemat` varchar(40) NOT NULL,
  `correo_electronico` varchar(40) NOT NULL,
  `estado` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `alumno`
-- 

INSERT INTO `alumno` VALUES ('Antonio', 'Morales', 'Montiel', 'antonio@hotmail.com', '');
INSERT INTO `alumno` VALUES ('sirio', 'tor', 'cru', 'tuti2012@hotmail.com', '');
INSERT INTO `alumno` VALUES ('Nico', 'Cordoba', 'Rivera', 'veronico_aries@hotmail.com', '');
INSERT INTO `alumno` VALUES ('Anel', 'Martinez', 'Palestina', 'Ani_23_ASD@hotmail.com', '');
INSERT INTO `alumno` VALUES ('Nico', 'Cordoba', 'Rivera', 'veronico_aries@hotmail.com', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cursos`
-- 

CREATE TABLE `cursos` (
  `idcurso` int(20) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `tipo` varchar(40) NOT NULL,
  `salon` varchar(40) NOT NULL,
  `horario` varchar(40) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_conclusion` date NOT NULL,
  `num_seciones` varchar(40) NOT NULL,
  PRIMARY KEY (`idcurso`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `cursos`
-- 

INSERT INTO `cursos` VALUES (1, 'program', 'bien', '105', '12am-13pm', '2014-05-01', '2014-05-31', '3');
INSERT INTO `cursos` VALUES (2, 'Programación Avanzada', 'programacion', '112', '11am a 5pm ', '2014-05-02', '2014-07-11', '5');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuario`
-- 

CREATE TABLE `usuario` (
  `idusuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) CHARACTER SET utf8 NOT NULL,
  `apepat` varchar(40) CHARACTER SET utf8 NOT NULL,
  `apemat` varchar(40) CHARACTER SET utf8 NOT NULL,
  `usuario` varchar(40) CHARACTER SET utf8 NOT NULL,
  `Email` varchar(40) CHARACTER SET utf8 NOT NULL,
  `password` varchar(40) CHARACTER SET utf8 NOT NULL,
  `confirmacion` varchar(40) CHARACTER SET utf8 NOT NULL,
  `rol` varchar(40) CHARACTER SET utf8 NOT NULL,
  `estado` varchar(45) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin AUTO_INCREMENT=70 ;

-- 
-- Volcar la base de datos para la tabla `usuario`
-- 

INSERT INTO `usuario` VALUES (66, 'Veronico', 'Cordoba', 'Rivera', 'root', 'veronico_aries@hotmail.com', '123', '123', 'Academico', 'Activo');
INSERT INTO `usuario` VALUES (67, '', 'cordoba', 'rivera', 'root3', 'veronico_aries@hotmail.com', '123', '123', 'Administrador', 'Activo');
INSERT INTO `usuario` VALUES (30, 'nico', 'Hernandez', 'Fernandez', 'root2', 'nico_12@hotmail.com', '345', '345', 'Academico', 'Inactivo');
INSERT INTO `usuario` VALUES (65, '', 'asfd', 'asd', 'ase', 'tuti2012@hotmail.com', 'primeape21', 'primeape21', 'Academico', 'Activo');
INSERT INTO `usuario` VALUES (68, 'Juan', 'Hernandez', 'Saldana', 'juanito', 'Juan_23_45@hotmail.com', '890', '890', 'Administrador', 'Activo');
INSERT INTO `usuario` VALUES (69, '', 'Perez', 'Arriga', 'Juan', 'jua_12345@hotmail.com', '3456', '3456', 'Academico', 'Activo');
